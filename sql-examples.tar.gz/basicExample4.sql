SELECT employee_id, first_name, last_name,
       hire_date, salary
FROM employees
ORDER BY first_name, last_name DESC;
