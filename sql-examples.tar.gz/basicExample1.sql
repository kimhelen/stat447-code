SELECT *
FROM employees
