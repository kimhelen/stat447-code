SELECT DISTINCT job_id, salary
FROM employees
ORDER BY job_id, salary DESC;
